"""
CMU 10799 Diffusion & Flow Matching Homework - Educational implementation of DDPM and Flow Matching

CMU 10-799: Diffusion & Flow Matching

Authors: Yutong (Kelly) He, Claude Code, Codex
"""

__version__ = "0.1.0"
